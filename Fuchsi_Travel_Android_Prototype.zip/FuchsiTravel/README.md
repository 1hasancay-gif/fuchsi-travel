# Fuchsi Travel

Offline-first Android prototype for A1 German learning through a Germany travel game.

## Learning design
A1 scope is aligned to CEFR A1 can-do goals and Goethe-Zertifikat A1 task types, with grammar sequencing informed by Deutsche Welle Nicos Weg A1. Lessons mix recognition, listening, retrieval, production, immediate feedback and spaced review.

## Build
The repository includes a GitHub Actions workflow that builds a debug APK on a GitHub runner using Gradle 8.9 + Android Gradle Plugin 8.7.3.

Open the Actions tab and run **Build Fuchsi Travel APK**. The APK is published as a workflow artifact.
